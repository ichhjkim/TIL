import React, { Component } from 'react';
import MyComponent from './MyComponent';

class App extends Component {
  state = {
    counter: 1
  };
  constructor(props) {
    super(props);
    console.log(constructor);
  } // component가 제일 먼저 만들어질때 실행되는 함수
  componentDidMount() {
    console.log('componentDidMound');
    console.log(this.myDiv.getBoundingClientRect());
  }
  handleClick = () => {
    this.setState({
      counter: this.state.counter + 1
    });
  };

  render() {
    return (
      <div ref={ref => (this.myDiv = ref)}>
        <MyComponent value={this.state.counter} />
        <button onClick={this.handleClick}>클릭</button>
      </div>
    );
  }
}

export default App;
