import React, { Component } from 'react';

class MyComponent extends Component {
  state = {
    value: 0
  };
  static getDerivedStateFromProps(nextProps, prevState) {
    if (prevState.value !== nextProps.value) {
      return {
        value: nextProps.value
      };
    }
    return null;
  }
  shouldComponentUpdate(nextProps, nextState) {
    if (nextProps.value === 10) return false; // 특정 조건에 따라 update를 막아줄 수 있는 함수
    return true;
  }
  render() {
    return (
      <div>
        <p>props: {this.props.value}</p>
        <p>state: {this.state.value}</p>
      </div>
    );
  }
}
export default MyComponent;
